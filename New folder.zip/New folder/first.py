# # l1 = ["apple","apple","apple","apple","apple","apple"]
# # print(l1)
# # l2 = []
# # for i in range(6) :
# #     a=int(input("Enter marks"))
# #     l2.append(a)
# #     l2.sort()
# # print(l2)
# # t1 = (1,"avd",34,"Ddsd")
# # print(t1)
# # t1[1] = 3 #Here we can see tuple is immutable
# a = (7,0,8,0,0,9)
# count = None
# for i in a :
#     if i == 0:
#         count=+1

# PROG 5
# l = float(input("Enter your length:- "))
# b = float(input("Enter your Breadth:- "))
# area = l*b
# print("Area of rectangle is:- ",area)

# PROG 6
# r = float(input("Enter radius:- "))
# area = 3.14*r*r
# print("Area of circle is:- ",area)

# PROG 7
# a = input("Enter any message: -")
# print("Your message was: -",a)

# PROG 8
# a = int(input("Enter a integer: -"))

# PROG 9
# a = [ ]
# n=int(input("Enter How many int to input: -"))
# for i in range(n):
#     b = int(input())
#     a.append(b)
# print("Entered integers are: -",a)

# PROG 10 : WAP to enter Name, marks of 5 subject and calculate total & percentage of student
# name = input("Enter your name:- ")
# print("Enter your marks of ENGLISH,MATHS,PHYSICS,CHEMISTRY,IP respectively")
# marks = []
# for i in range(5): 
#     b=float(input())
#     marks.append(b)
# print("Your name is: -",name)
# print("Marks:- ",marks)

# PROG 11 : WAP to enter distance in feet and convert it into inches
