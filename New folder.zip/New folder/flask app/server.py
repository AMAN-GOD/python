from flask import Flask, render_template, request, redirect, url_for, session, flash
import random

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # For session management

# Mock database
list_username = []
list_password = []
list_account_no = []
list_balance = []

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Registration route
@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']

    if username and password:
        list_username.append(username)
        list_password.append(password)
        account_no = random.randint(10**14, 10**15 - 1)
        list_account_no.append(account_no)
        list_balance.append(0)
        flash(f"User {username} registered successfully! Your account number is {account_no}.")
    else:
        flash("Username and password cannot be empty.")
    
    return redirect(url_for('home'))

# Login route
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    if username in list_username:
        index = list_username.index(username)
        if list_password[index] == password:
            session['username'] = username
            session['index'] = index
            return redirect(url_for('dashboard'))
        else:
            flash("Incorrect password.")
    else:
        flash("User not found.")
    
    return redirect(url_for('home'))

# Dashboard route
@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('home'))
    
    username = session['username']
    index = session['index']
    balance = list_balance[index]
    
    return render_template('dashboard.html', username=username, balance=balance)

# Deposit route
@app.route('/deposit', methods=['POST'])
def deposit():
    amount = float(request.form['amount'])
    index = session['index']
    list_balance[index] += amount
    flash(f"Deposited {amount}. New balance: {list_balance[index]}")
    return redirect(url_for('dashboard'))

# Withdraw route
@app.route('/withdraw', methods=['POST'])
def withdraw():
    amount = float(request.form['amount'])
    index = session['index']

    if amount <= list_balance[index]:
        list_balance[index] -= amount
        flash(f"Withdrew {amount}. New balance: {list_balance[index]}")
    else:
        flash("Insufficient balance.")
    
    return redirect(url_for('dashboard'))

# Logout route
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
